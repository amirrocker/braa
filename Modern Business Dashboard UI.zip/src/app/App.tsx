import { useState } from "react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  Zap,
  Calendar,
  MessageSquare,
  Users,
  CheckCircle,
  AlertCircle,
  DollarSign,
  Star,
  Wrench,
  Bell,
  Settings,
  ArrowUpRight,
  ArrowDownRight,
  LayoutDashboard,
  Clock,
  MapPin,
  User,
  Shield,
  Phone,
  Send,
  Search,
  Plus,
  Menu,
  Mail,
} from "lucide-react";

// ─── DATA ────────────────────────────────────────────────────────────────────

const revenueData = [
  { month: "Mar", revenue: 18200 },
  { month: "Apr", revenue: 21500 },
  { month: "May", revenue: 19800 },
  { month: "Jun", revenue: 23100 },
  { month: "Jul", revenue: 22400 },
  { month: "Aug", revenue: 24850 },
];

const jobTypeData = [
  { name: "Residential", value: 45, color: "#F59E0B" },
  { name: "Commercial", value: 30, color: "#3B82F6" },
  { name: "Emergency", value: 15, color: "#EF4444" },
  { name: "Industrial", value: 10, color: "#10B981" },
];

const weeklyJobsData = [
  { day: "Mon", completed: 8, active: 2 },
  { day: "Tue", completed: 10, active: 3 },
  { day: "Wed", completed: 7, active: 4 },
  { day: "Thu", completed: 9, active: 2 },
  { day: "Fri", completed: 11, active: 1 },
  { day: "Sat", completed: 5, active: 2 },
];

const kpis = [
  { label: "Revenue This Month", value: "$24,850", change: "+12.4%", positive: true, icon: DollarSign, sub: "vs $22,107 last month" },
  { label: "Jobs Completed", value: "47", change: "+8.3%", positive: true, icon: CheckCircle, sub: "Target: 50 this month" },
  { label: "Active Jobs", value: "12", change: null, positive: null, icon: Wrench, sub: "3 urgent · 9 standard" },
  { label: "Pending Invoices", value: "$8,340", change: "-5.1%", positive: false, icon: AlertCircle, sub: "6 invoices outstanding" },
  { label: "Team Utilization", value: "87%", change: "+4%", positive: true, icon: Users, sub: "4 of 5 techs active" },
  { label: "Customer Rating", value: "4.9 ★", change: "+0.1", positive: true, icon: Star, sub: "Based on 34 reviews" },
];

const appointments = [
  { id: 1, time: "08:00", end: "10:00", customer: "Robert Harmon", address: "42 Elmwood Drive", job: "Panel Upgrade 200A", status: "completed", tech: "Mike Chen", priority: "normal" },
  { id: 2, time: "09:30", end: "11:30", customer: "Lakeside Properties LLC", address: "18 Commerce Blvd, Unit 4", job: "Commercial Inspection & Cert.", status: "in-progress", tech: "Sarah Webb", priority: "high" },
  { id: 3, time: "11:00", end: "12:00", customer: "Diana Morales", address: "7 Birch Lane, Westside", job: "EV Charger Installation", status: "upcoming", tech: "Tom Reeves", priority: "normal" },
  { id: 4, time: "13:00", end: "14:30", customer: "Green Valley School", address: "150 School Road", job: "Emergency – Breaker Failure", status: "upcoming", tech: "Mike Chen", priority: "urgent" },
  { id: 5, time: "14:30", end: "16:00", customer: "Frank Kowalski", address: "88 Maple Street", job: "GFCI Outlet Replacement", status: "upcoming", tech: "Sarah Webb", priority: "normal" },
  { id: 6, time: "16:00", end: "18:00", customer: "The Grand Hotel", address: "1 Harbor View, Downtown", job: "LED Retrofit & Lighting Control", status: "upcoming", tech: "Tom Reeves", priority: "high" },
];

const messages = [
  { id: 1, contact: "Diana Morales", dir: "in" as const, time: "09:14", text: "Hi, just confirming my 11am appointment is still on? I will be home. Also, could you check the outdoor socket on the back porch — it stopped working last week.", read: false, channel: "sms" },
  { id: 2, contact: "Mike Chen", dir: "in" as const, time: "08:47", text: "Panel job at Harmon is done. Customer signed off. Moving to Green Valley at noon — the principal wants to meet before we start. Should I call them?", read: true, channel: "team" },
  { id: 3, contact: "Frank Kowalski", dir: "out" as const, time: "08:30", text: "Frank, we will be with you around 2:30pm today. Tom will be handling your job. Please have access to the breaker box ready when he arrives.", read: true, channel: "sms" },
  { id: 4, contact: "Lakeside Properties", dir: "in" as const, time: "Yesterday", text: "Sarah did a fantastic job on the inspection — very professional and thorough. Will definitely be calling again for our next project.", read: true, channel: "email" },
  { id: 5, contact: "Green Valley School", dir: "out" as const, time: "Yesterday", text: "Your emergency job is confirmed for 1pm tomorrow. Our senior tech Mike will be on site. Please call us immediately if the situation worsens overnight.", read: true, channel: "email" },
  { id: 6, contact: "Tom Reeves", dir: "in" as const, time: "Yesterday", text: "Parts for the Grand Hotel job arrived this afternoon. All good for tomorrow. I grabbed 3 extra LED drivers just in case.", read: true, channel: "team" },
];

const team = [
  { id: 1, name: "Mike Chen", role: "Senior Electrician", phone: "555-201-4423", status: "on-job", job: "Emergency – Green Valley School", jobs: 12, hours: 38, util: 95, certs: ["Master Electrician", "OSHA 30", "EV Certified"], initials: "MC", color: "#F59E0B" },
  { id: 2, name: "Sarah Webb", role: "Journeyman Electrician", phone: "555-382-9910", status: "on-job", job: "Commercial Inspection – Lakeside", jobs: 9, hours: 34, util: 85, certs: ["Journeyman License", "OSHA 10", "Arc Flash"], initials: "SW", color: "#3B82F6" },
  { id: 3, name: "Tom Reeves", role: "Electrician", phone: "555-447-3301", status: "available", job: null as string | null, jobs: 8, hours: 30, util: 75, certs: ["Apprentice License", "OSHA 10"], initials: "TR", color: "#10B981" },
  { id: 4, name: "Lisa Park", role: "Apprentice", phone: "555-561-8874", status: "training", job: "Safety Recertification Training", jobs: 5, hours: 28, util: 60, certs: ["Apprentice License"], initials: "LP", color: "#8B5CF6" },
  { id: 5, name: "Carlos Vega", role: "Senior Electrician", phone: "555-629-1140", status: "off", job: null as string | null, jobs: 0, hours: 0, util: 0, certs: ["Master Electrician", "OSHA 30", "Solar PV"], initials: "CV", color: "#EF4444" },
];

// ─── SHARED COMPONENTS ───────────────────────────────────────────────────────

function ChartTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ name: string; value: number; color: string }>; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#0B1020] border border-[#1A2540] rounded-lg p-3 text-xs shadow-2xl">
      <p className="text-slate-400 mb-1.5 font-medium">{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color }} className="font-mono">
          {p.name}: {p.name === "Revenue" ? `$${p.value.toLocaleString()}` : p.value}
        </p>
      ))}
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const cfg: Record<string, { label: string; cls: string }> = {
    completed: { label: "Completed", cls: "bg-emerald-500/10 text-emerald-400 border-emerald-500/25" },
    "in-progress": { label: "In Progress", cls: "bg-amber-500/10 text-amber-400 border-amber-500/25" },
    upcoming: { label: "Upcoming", cls: "bg-slate-700/40 text-slate-400 border-slate-600/25" },
    urgent: { label: "Urgent", cls: "bg-red-500/10 text-red-400 border-red-500/25" },
    "on-job": { label: "On Job", cls: "bg-amber-500/10 text-amber-400 border-amber-500/25" },
    available: { label: "Available", cls: "bg-emerald-500/10 text-emerald-400 border-emerald-500/25" },
    training: { label: "Training", cls: "bg-violet-500/10 text-violet-400 border-violet-500/25" },
    off: { label: "Day Off", cls: "bg-slate-700/20 text-slate-500 border-slate-700/25" },
  };
  const c = cfg[status] ?? cfg.upcoming;
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium border ${c.cls}`}>
      {c.label}
    </span>
  );
}

function PriorityDot({ priority }: { priority: string }) {
  const cls: Record<string, string> = { urgent: "bg-red-500 ring-red-500/30", high: "bg-amber-400 ring-amber-400/30", normal: "bg-slate-600" };
  return <span className={`inline-block w-2 h-2 rounded-full ring-2 ring-transparent ${cls[priority] ?? cls.normal}`} />;
}

function Avatar({ initials, color, size = "sm" }: { initials: string; color: string; size?: "sm" | "md" | "lg" }) {
  const sz = { sm: "w-7 h-7 text-xs", md: "w-9 h-9 text-sm", lg: "w-11 h-11 text-base" }[size];
  return (
    <div className={`${sz} rounded-full flex items-center justify-center font-bold text-slate-900 shrink-0`} style={{ background: color }}>
      {initials}
    </div>
  );
}

// ─── OVERVIEW TAB ────────────────────────────────────────────────────────────

function OverviewTab() {
  return (
    <div className="p-6 space-y-5">
      {/* KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
        {kpis.map((kpi) => {
          const Icon = kpi.icon;
          return (
            <div key={kpi.label} className="bg-[#0B1020] border border-[#1A2540] rounded-xl p-4 hover:border-amber-500/20 transition-colors group">
              <div className="flex items-start justify-between mb-3">
                <div className="p-2 bg-amber-500/10 rounded-lg group-hover:bg-amber-500/15 transition-colors">
                  <Icon className="w-4 h-4 text-amber-400" />
                </div>
                {kpi.change !== null && (
                  <div className={`flex items-center gap-0.5 text-xs font-mono ${kpi.positive ? "text-emerald-400" : "text-red-400"}`}>
                    {kpi.positive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                    {kpi.change}
                  </div>
                )}
              </div>
              <div className="font-mono text-2xl font-semibold text-slate-100 tracking-tight">{kpi.value}</div>
              <div className="text-xs text-slate-500 mt-0.5 font-medium">{kpi.label}</div>
              <div className="text-xs text-slate-600 mt-1">{kpi.sub}</div>
            </div>
          );
        })}
      </div>

      {/* Charts row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Revenue Area Chart */}
        <div className="lg:col-span-2 bg-[#0B1020] border border-[#1A2540] rounded-xl p-5">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-sm font-semibold text-slate-200" style={{ fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.04em" }}>MONTHLY REVENUE</h3>
              <p className="text-xs text-slate-600 mt-0.5">Last 6 months</p>
            </div>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-md">↑ 12.4% vs prior month</span>
          </div>
          <ResponsiveContainer width="100%" height={175}>
            <AreaChart data={revenueData} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="#F59E0B" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1A2540" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: "#475569", fontSize: 11, fontFamily: "JetBrains Mono" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#475569", fontSize: 11, fontFamily: "JetBrains Mono" }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
              <Tooltip content={<ChartTooltip />} cursor={{ stroke: "#1A2540", strokeWidth: 1 }} />
              <Area type="monotone" dataKey="revenue" name="Revenue" stroke="#F59E0B" strokeWidth={2} fill="url(#revGrad)" dot={{ fill: "#F59E0B", r: 3, strokeWidth: 0 }} activeDot={{ r: 5, fill: "#F59E0B" }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Job Types Donut */}
        <div className="bg-[#0B1020] border border-[#1A2540] rounded-xl p-5">
          <div className="mb-4">
            <h3 className="text-sm font-semibold text-slate-200" style={{ fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.04em" }}>JOBS BY TYPE</h3>
            <p className="text-xs text-slate-600 mt-0.5">This month</p>
          </div>
          <ResponsiveContainer width="100%" height={145}>
            <PieChart>
              <Pie data={jobTypeData} cx="50%" cy="50%" innerRadius={42} outerRadius={66} paddingAngle={3} dataKey="value" strokeWidth={0}>
                {jobTypeData.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip content={<ChartTooltip />} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-1">
            {jobTypeData.map((d) => (
              <div key={d.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full" style={{ background: d.color }} />
                  <span className="text-slate-400">{d.name}</span>
                </div>
                <span className="font-mono text-slate-300">{d.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Charts row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Weekly Jobs Bar */}
        <div className="lg:col-span-2 bg-[#0B1020] border border-[#1A2540] rounded-xl p-5">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-sm font-semibold text-slate-200" style={{ fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.04em" }}>WEEKLY JOBS</h3>
              <p className="text-xs text-slate-600 mt-0.5">Current week</p>
            </div>
            <div className="flex gap-4 text-xs">
              <span className="flex items-center gap-1.5 text-slate-500">
                <span className="w-2.5 h-2.5 rounded-sm bg-amber-500 inline-block" />Completed
              </span>
              <span className="flex items-center gap-1.5 text-slate-500">
                <span className="w-2.5 h-2.5 rounded-sm bg-blue-500 inline-block" />Active
              </span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={155}>
            <BarChart data={weeklyJobsData} margin={{ top: 5, right: 5, bottom: 0, left: 0 }} barSize={14} barGap={3}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1A2540" vertical={false} />
              <XAxis dataKey="day" tick={{ fill: "#475569", fontSize: 11, fontFamily: "JetBrains Mono" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#475569", fontSize: 11, fontFamily: "JetBrains Mono" }} axisLine={false} tickLine={false} />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
              <Bar dataKey="completed" name="Completed" fill="#F59E0B" radius={[3, 3, 0, 0]} />
              <Bar dataKey="active" name="Active" fill="#3B82F6" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Today's Timeline */}
        <div className="bg-[#0B1020] border border-[#1A2540] rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-slate-200" style={{ fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.04em" }}>TODAY</h3>
            <span className="text-xs font-mono text-slate-600">Aug 16, 2026</span>
          </div>
          <div className="space-y-0">
            {appointments.slice(0, 5).map((apt, idx) => (
              <div key={apt.id} className="flex items-start gap-3 relative">
                <div className="flex flex-col items-center">
                  <div className="text-xs font-mono text-amber-400/80 mt-1 min-w-[3rem] text-right">{apt.time}</div>
                </div>
                <div className="flex flex-col items-center mx-1 pt-1">
                  <div className={`w-2 h-2 rounded-full shrink-0 ${apt.status === "completed" ? "bg-emerald-500" : apt.status === "in-progress" ? "bg-amber-400" : "bg-slate-600"}`} />
                  {idx < appointments.length - 2 && <div className="w-px flex-1 bg-[#1A2540] my-1" style={{ minHeight: "24px" }} />}
                </div>
                <div className="flex-1 pb-3">
                  <p className="text-xs font-medium text-slate-300 truncate">{apt.customer}</p>
                  <p className="text-xs text-slate-600 truncate mt-0.5">{apt.job}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── SCHEDULE TAB ────────────────────────────────────────────────────────────

function ScheduleTab() {
  const [selected, setSelected] = useState<typeof appointments[0] | null>(null);

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-slate-100" style={{ fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.05em" }}>SCHEDULE</h2>
          <p className="text-sm text-slate-500">Saturday, August 16, 2026</p>
        </div>
        <button className="flex items-center gap-2 bg-amber-500 text-slate-900 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-amber-400 transition-colors">
          <Plus className="w-4 h-4" />New Appointment
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
        {/* Appointment List */}
        <div className="lg:col-span-3 space-y-2.5">
          {appointments.map((apt) => (
            <div
              key={apt.id}
              onClick={() => setSelected(selected?.id === apt.id ? null : apt)}
              className={`bg-[#0B1020] border rounded-xl p-4 cursor-pointer transition-all ${selected?.id === apt.id ? "border-amber-500/40" : "border-[#1A2540] hover:border-slate-600/50"}`}
            >
              <div className="flex items-start gap-4">
                <div className="min-w-[3.5rem] text-right">
                  <div className="text-sm font-mono font-semibold text-amber-400">{apt.time}</div>
                  <div className="text-xs font-mono text-slate-600">–{apt.end}</div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <PriorityDot priority={apt.priority} />
                    <span className="text-sm font-semibold text-slate-100">{apt.customer}</span>
                    <StatusBadge status={apt.status} />
                  </div>
                  <p className="text-sm text-amber-400/70 font-medium mb-1.5">{apt.job}</p>
                  <div className="flex items-center gap-4 text-xs text-slate-500">
                    <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{apt.address}</span>
                    <span className="flex items-center gap-1"><User className="w-3 h-3" />{apt.tech}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Side Panel */}
        <div className="lg:col-span-2 space-y-4">
          {selected ? (
            <div className="bg-[#0B1020] border border-amber-500/30 rounded-xl p-5">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-sm font-semibold text-slate-100">{selected.customer}</h3>
                  <p className="text-xs text-slate-500 mt-0.5">{selected.address}</p>
                </div>
                <StatusBadge status={selected.status} />
              </div>
              <div className="space-y-3 text-sm text-slate-400">
                <div className="flex items-center gap-2.5">
                  <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                  <span className="font-mono text-slate-300">{selected.time} – {selected.end}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Wrench className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>{selected.job}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <User className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>{selected.tech}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <PriorityDot priority={selected.priority} />
                  <span className="capitalize">{selected.priority} priority</span>
                </div>
              </div>
              <div className="mt-5 pt-4 border-t border-[#1A2540] flex gap-2.5">
                <button className="flex-1 bg-amber-500/10 text-amber-400 border border-amber-500/25 rounded-lg py-2 text-xs font-semibold hover:bg-amber-500/15 transition-colors">
                  Edit Job
                </button>
                <button className="flex-1 bg-slate-800/40 text-slate-300 border border-slate-700/30 rounded-lg py-2 text-xs font-semibold hover:bg-slate-800/60 transition-colors">
                  Contact
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-[#0B1020] border border-[#1A2540] rounded-xl p-5">
              <h3 className="text-sm font-semibold text-slate-400 mb-4" style={{ fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.04em" }}>DAILY SUMMARY</h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: "Total Jobs", val: "6", color: "text-slate-200" },
                  { label: "Completed", val: "1", color: "text-emerald-400" },
                  { label: "In Progress", val: "1", color: "text-amber-400" },
                  { label: "Upcoming", val: "4", color: "text-slate-400" },
                ].map((s) => (
                  <div key={s.label} className="bg-[#0A0D15] rounded-lg p-3 text-center border border-[#1A2540]">
                    <div className={`text-xl font-mono font-semibold ${s.color}`}>{s.val}</div>
                    <div className="text-xs text-slate-600 mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>
              <p className="text-xs text-slate-600 text-center mt-3">Select a job to view details</p>
            </div>
          )}

          {/* Tech Allocation */}
          <div className="bg-[#0B1020] border border-[#1A2540] rounded-xl p-5">
            <h3 className="text-sm font-semibold text-slate-400 mb-4" style={{ fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.04em" }}>TECH ALLOCATION</h3>
            <div className="space-y-4">
              {team.filter((t) => t.status !== "off" && t.status !== "training").map((t) => {
                const todayCount = appointments.filter((a) => a.tech === t.name).length;
                return (
                  <div key={t.id} className="flex items-center gap-3">
                    <Avatar initials={t.initials} color={t.color} size="sm" />
                    <div className="flex-1">
                      <div className="flex justify-between text-xs mb-1.5">
                        <span className="text-slate-300 font-medium">{t.name}</span>
                        <span className="text-slate-500 font-mono">{todayCount} jobs</span>
                      </div>
                      <div className="h-1.5 bg-[#0A0D15] rounded-full overflow-hidden">
                        <div className="h-full rounded-full transition-all" style={{ width: `${Math.min(todayCount * 33, 100)}%`, background: t.color }} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── MESSAGES TAB ────────────────────────────────────────────────────────────

function MessagesTab() {
  const [selected, setSelected] = useState(messages[0]);
  const [reply, setReply] = useState("");

  const channelIcon = (ch: string) => {
    if (ch === "email") return <Mail className="w-3 h-3" />;
    if (ch === "team") return <Users className="w-3 h-3" />;
    return <Phone className="w-3 h-3" />;
  };

  const initials = (name: string) =>
    name.split(" ").map((w) => w[0]).join("").slice(0, 2);

  return (
    <div className="p-6 flex flex-col" style={{ height: "calc(100vh - 56px)" }}>
      <div className="flex items-center justify-between mb-5 shrink-0">
        <div>
          <h2 className="text-lg font-semibold text-slate-100" style={{ fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.05em" }}>MESSAGES</h2>
          <p className="text-sm text-slate-500">Customer & team communications</p>
        </div>
        <div className="flex items-center gap-2 bg-[#0B1020] border border-[#1A2540] rounded-lg px-3 py-2">
          <Search className="w-4 h-4 text-slate-600" />
          <input className="bg-transparent text-sm text-slate-300 placeholder-slate-600 outline-none w-36" placeholder="Search messages..." />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 flex-1 min-h-0">
        {/* List */}
        <div className="lg:col-span-2 overflow-y-auto space-y-2 pr-1 [&::-webkit-scrollbar]:w-1 [&::-webkit-scrollbar-track]:transparent [&::-webkit-scrollbar-thumb]:bg-slate-700/40">
          {messages.map((msg) => (
            <div
              key={msg.id}
              onClick={() => setSelected(msg)}
              className={`bg-[#0B1020] border rounded-xl p-4 cursor-pointer transition-all ${
                selected?.id === msg.id ? "border-amber-500/40" : `border-[#1A2540] hover:border-slate-600/50 ${!msg.read ? "border-l-2 border-l-amber-500" : ""}`
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2.5">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${msg.dir === "in" ? "bg-slate-800 text-slate-300" : "bg-amber-500/15 text-amber-400"}`}>
                    {initials(msg.contact)}
                  </div>
                  <div>
                    <p className={`text-sm font-medium ${!msg.read ? "text-slate-100" : "text-slate-400"}`}>{msg.contact}</p>
                    <div className="flex items-center gap-1 text-slate-600 text-xs mt-0.5">
                      {channelIcon(msg.channel)}
                      <span className="capitalize ml-0.5">{msg.channel}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-600 font-mono">{msg.time}</span>
                  {!msg.read && <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />}
                </div>
              </div>
              <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                {msg.dir === "out" && <span className="text-amber-500/60">↗ </span>}{msg.text}
              </p>
            </div>
          ))}
        </div>

        {/* Detail */}
        <div className="lg:col-span-3 bg-[#0B1020] border border-[#1A2540] rounded-xl flex flex-col overflow-hidden">
          {selected && (
            <>
              <div className="p-4 border-b border-[#1A2540] flex items-center justify-between shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-slate-800 flex items-center justify-center text-sm font-bold text-slate-300">
                    {initials(selected.contact)}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-200">{selected.contact}</p>
                    <div className="flex items-center gap-1 text-xs text-slate-500 mt-0.5">
                      {channelIcon(selected.channel)}
                      <span className="capitalize ml-0.5">{selected.channel}</span>
                      <span className="mx-1.5 text-slate-700">·</span>
                      <span>{selected.time}</span>
                    </div>
                  </div>
                </div>
                <span className={`text-xs font-medium px-2 py-1 rounded-md ${selected.dir === "out" ? "bg-amber-500/10 text-amber-400" : "bg-emerald-500/10 text-emerald-400"}`}>
                  {selected.dir === "out" ? "Sent" : "Received"}
                </span>
              </div>

              <div className="flex-1 p-5 overflow-y-auto [&::-webkit-scrollbar]:w-1 [&::-webkit-scrollbar-thumb]:bg-slate-700/40">
                <div className={`max-w-[80%] ${selected.dir === "out" ? "ml-auto" : ""}`}>
                  <div className={`rounded-2xl p-4 text-sm leading-relaxed ${
                    selected.dir === "out"
                      ? "bg-amber-500/12 text-slate-200 border border-amber-500/20"
                      : "bg-[#111827] text-slate-300 border border-[#1A2540]"
                  }`}>
                    {selected.text}
                  </div>
                  <p className={`text-xs text-slate-600 mt-2 font-mono ${selected.dir === "out" ? "text-right" : ""}`}>{selected.time}</p>
                </div>
              </div>

              <div className="p-4 border-t border-[#1A2540] shrink-0">
                <div className="flex items-center gap-3">
                  <input
                    value={reply}
                    onChange={(e) => setReply(e.target.value)}
                    placeholder={`Reply to ${selected.contact}...`}
                    className="flex-1 bg-[#0A0D15] border border-[#1A2540] rounded-lg px-4 py-2.5 text-sm text-slate-300 placeholder-slate-600 outline-none focus:border-amber-500/40 transition-colors"
                  />
                  <button
                    onClick={() => setReply("")}
                    className="p-2.5 bg-amber-500 rounded-lg text-slate-900 hover:bg-amber-400 transition-colors shrink-0"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── TEAM TAB ────────────────────────────────────────────────────────────────

function TeamTab() {
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-slate-100" style={{ fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.05em" }}>TEAM</h2>
          <p className="text-sm text-slate-500">5 members · 4 active today</p>
        </div>
        <button className="flex items-center gap-2 bg-amber-500 text-slate-900 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-amber-400 transition-colors">
          <Plus className="w-4 h-4" />Add Member
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
        {team.map((member) => (
          <div key={member.id} className="bg-[#0B1020] border border-[#1A2540] rounded-xl p-5 hover:border-slate-600/50 transition-colors">
            <div className="flex items-start gap-3.5 mb-4">
              <Avatar initials={member.initials} color={member.color} size="lg" />
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-semibold text-slate-100">{member.name}</h3>
                    <p className="text-xs text-slate-500 mt-0.5">{member.role}</p>
                  </div>
                  <StatusBadge status={member.status} />
                </div>
              </div>
            </div>

            {member.job && (
              <div className="bg-[#0A0D15] rounded-lg p-3 mb-4 border border-[#1A2540]">
                <div className="flex items-start gap-2">
                  <Wrench className="w-3 h-3 text-amber-400 mt-0.5 shrink-0" />
                  <p className="text-xs text-slate-400 leading-relaxed">{member.job}</p>
                </div>
              </div>
            )}

            <div className="grid grid-cols-3 gap-3 mb-4">
              {[
                { label: "Jobs/Wk", val: String(member.jobs) },
                { label: "Hours", val: String(member.hours) },
                { label: "Util.", val: `${member.util}%` },
              ].map((s) => (
                <div key={s.label} className="text-center bg-[#0A0D15] rounded-lg py-2.5 border border-[#1A2540]">
                  <div className="text-sm font-mono font-semibold text-slate-200">{s.val}</div>
                  <div className="text-xs text-slate-600 mt-0.5">{s.label}</div>
                </div>
              ))}
            </div>

            <div className="mb-4">
              <div className="h-1.5 bg-[#0A0D15] rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all"
                  style={{ width: `${member.util}%`, background: member.color, opacity: member.util > 0 ? 1 : 0.2 }}
                />
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5 mb-4">
              {member.certs.map((c) => (
                <span key={c} className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-800/50 border border-slate-700/30 rounded-md text-xs text-slate-500">
                  <Shield className="w-2.5 h-2.5" />
                  {c}
                </span>
              ))}
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-[#1A2540]">
              <div className="flex items-center gap-1.5 text-xs text-slate-600 font-mono">
                <Phone className="w-3 h-3" />
                {member.phone}
              </div>
              <button className="text-xs text-amber-400/70 hover:text-amber-400 font-medium transition-colors">
                Details →
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── APP ─────────────────────────────────────────────────────────────────────

const tabs = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "schedule", label: "Schedule", icon: Calendar },
  { id: "messages", label: "Messages", icon: MessageSquare },
  { id: "team", label: "Team", icon: Users },
];

export default function App() {
  const [activeTab, setActiveTab] = useState("overview");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const unread = messages.filter((m) => !m.read).length;

  return (
    <div className="flex h-screen bg-[#07090D] overflow-hidden" style={{ fontFamily: "DM Sans, system-ui, sans-serif" }}>
      {/* Sidebar */}
      <aside
        className={`${sidebarOpen ? "w-56" : "w-[60px]"} bg-[#0B0E14] border-r border-[#1A2540] flex flex-col shrink-0 transition-[width] duration-200`}
      >
        {/* Logo */}
        <div className="h-14 flex items-center px-4 border-b border-[#1A2540] shrink-0">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-7 h-7 bg-amber-500 rounded-lg flex items-center justify-center shrink-0">
              <Zap className="w-4 h-4 text-slate-900" fill="currentColor" />
            </div>
            {sidebarOpen && (
              <span style={{ fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.08em" }} className="text-base font-bold">
                <span className="text-slate-100">VOLT</span>
                <span className="text-amber-400">PRO</span>
              </span>
            )}
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-2.5 space-y-1 overflow-hidden">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all relative ${
                  active ? "bg-amber-500/12 text-amber-400" : "text-slate-500 hover:text-slate-300 hover:bg-slate-800/40"
                }`}
              >
                {active && <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-amber-400 rounded-r-full" />}
                <Icon className="w-4 h-4 shrink-0" />
                {sidebarOpen && <span className="truncate">{tab.label}</span>}
                {tab.id === "messages" && unread > 0 && (
                  <span className={`bg-amber-500 text-slate-900 text-xs font-bold rounded-full w-4 h-4 flex items-center justify-center shrink-0 ${sidebarOpen ? "ml-auto" : "absolute top-1 right-1 w-3 h-3 text-[9px]"}`}>
                    {unread}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom */}
        <div className="p-2.5 border-t border-[#1A2540] space-y-1 shrink-0">
          <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-slate-500 hover:text-slate-300 hover:bg-slate-800/40 transition-all">
            <Settings className="w-4 h-4 shrink-0" />
            {sidebarOpen && <span>Settings</span>}
          </button>
          <div className="flex items-center gap-3 px-3 py-2">
            <div className="w-7 h-7 rounded-full bg-amber-500 flex items-center justify-center text-xs font-bold text-slate-900 shrink-0">JD</div>
            {sidebarOpen && (
              <div className="min-w-0">
                <p className="text-xs font-semibold text-slate-300 truncate">James Davis</p>
                <p className="text-xs text-slate-600 truncate">Owner</p>
              </div>
            )}
          </div>
        </div>
      </aside>

      {/* Main area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Topbar */}
        <header className="h-14 bg-[#0B0E14] border-b border-[#1A2540] flex items-center justify-between px-5 shrink-0">
          <div className="flex items-center gap-4">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-slate-500 hover:text-slate-300 transition-colors">
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="text-sm font-semibold text-slate-300 tracking-widest" style={{ fontFamily: "Rajdhani, sans-serif" }}>
              {tabs.find((t) => t.id === activeTab)?.label.toUpperCase()}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs font-mono text-slate-600">SAT 16 AUG 2026</span>
            <div className="h-4 w-px bg-slate-800" />
            <button className="relative p-2 text-slate-500 hover:text-slate-300 transition-colors">
              <Bell className="w-4 h-4" />
              {unread > 0 && <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-amber-500 rounded-full" />}
            </button>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto [&::-webkit-scrollbar]:w-1.5 [&::-webkit-scrollbar-track]:transparent [&::-webkit-scrollbar-thumb]:bg-slate-700/30 [&::-webkit-scrollbar-thumb]:rounded-full">
          {activeTab === "overview" && <OverviewTab />}
          {activeTab === "schedule" && <ScheduleTab />}
          {activeTab === "messages" && <MessagesTab />}
          {activeTab === "team" && <TeamTab />}
        </main>
      </div>
    </div>
  );
}
